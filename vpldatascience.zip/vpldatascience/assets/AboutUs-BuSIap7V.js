import{_ as e,c,o}from"./index-BY4ZjSPd.js";const t={};function n(r,s){return o(),c("div",null,"AboutUs")}const a=e(t,[["render",n]]);export{a as default};
