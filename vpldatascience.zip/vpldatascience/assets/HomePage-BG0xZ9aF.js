import{_ as e,c,o}from"./index-BY4ZjSPd.js";const n={};function r(t,a){return o(),c("div",null,"HomePage")}const _=e(n,[["render",r]]);export{_ as default};
